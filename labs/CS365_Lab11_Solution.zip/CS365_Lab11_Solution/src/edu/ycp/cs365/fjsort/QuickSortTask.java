package edu.ycp.cs365.fjsort;

import java.util.Arrays;
import java.util.concurrent.RecursiveAction;

public class QuickSortTask extends RecursiveAction {
	private static final long serialVersionUID = 1L;
	
	private int[] arr;
	private int start;
	private int end;
	private int threshold;

	/**
	 * Constructor.
	 * 
	 * @param arr         the array
	 * @param start       the index of the first element (inclusive)
	 * @param end         the index of the last element (exclusive)
	 * @param threshold   threshold: if there are fewer elements than this value,
	 *                    the sorting will be done sequentially
	 */
	public QuickSortTask(int[] arr, int start, int end, int threshold) {
		this.arr = arr;
		this.start = start;
		this.end = end;
		this.threshold = threshold;
	}

	@Override
	protected void compute() {
		// TODO
		
		// If the number of elements is less than the threshold,
		// sort sequentially
		int n = end - start;
		if (n < threshold) {
			Sort.quickSort(arr, start, end);
			return;
		}
		
		// Otherwise, partition, create two subtasks, fork them, and join them
		int mid = Sort.partition(arr, start, end);
		QuickSortTask left = new QuickSortTask(arr, start, mid, threshold);
		QuickSortTask right = new QuickSortTask(arr, mid+1, end, threshold);

		left.fork();
		right.fork();

		left.join();
		right.join();
	}
}
