#include <stdio.h>
#include <math.h>
#include <mpi.h>

// This is the function we're integrating
double func(double x)
{
	// y = sin(x) + x^1.3 cos(x) + x ln(x)
	double y = sin(x) + pow(x, 1.3)*cos(x) + x*log(x);
	return y;
}

int main(int argc, char **argv)
{
	MPI_Init(&argc, &argv);

	int rank, size;
	MPI_Comm_rank(MPI_COMM_WORLD, &rank);
	MPI_Comm_size(MPI_COMM_WORLD, &size);

	double xmin, xmax;
	int nrects;

	if (rank == 0) {
		printf("xmin: ");
		fflush(stdout);
		scanf("%lf", &xmin);
	
		printf("xmax: ");
		fflush(stdout);
		scanf("%lf", &xmax);
	
		printf("nrects: ");
		fflush(stdout);
		scanf("%i", &nrects);
	}

	// Broadcast input values
	MPI_Bcast(&xmin, 1, MPI_DOUBLE, 0, MPI_COMM_WORLD);
	MPI_Bcast(&xmax, 1, MPI_DOUBLE, 0, MPI_COMM_WORLD);
	MPI_Bcast(&nrects, 1, MPI_INT, 0, MPI_COMM_WORLD);

	// Divide up work
	int start, chunk_size;
	chunk_size = nrects / size; // number of rectangles this process will work on
	start = rank * chunk_size; // first rectangle this process will work on
	if (rank == size-1) {
		// Last process gets excess if the number of rectangles
		// isn't evenly divided by the number of processes
		chunk_size += nrects % size;
	}

	// total width of overall region being integrated
	double w = xmax-xmin;

	// width of one rectangle
	double rw = w/nrects;

	// Local computation
	double local_area = 0.0;
	for (int i = start; i < start+chunk_size; i++) {
		// determine x coordinates of left and right side of rectangle
		double rmin = xmin + (i*rw);
		double rmax = rmin + rw;
		// determine midpoint of rectangle
		double mid = (rmin+rmax)/2.0;
		// the value of the function at the midpoint is the height of the rectangle
		double y = func(mid);
		// area of rectangle
		double r_area = rw * y;

		local_area += r_area;
	}

	// Reduce local partial results to produce one global result
	double global_area;
	MPI_Reduce(&local_area, &global_area, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);

	// Print the global result (process 0 only)
	if (rank == 0) {
		printf("Area estimate is %lf\n", global_area);
	}

	MPI_Finalize();

	return 0;
}

// vim:ts=2:
