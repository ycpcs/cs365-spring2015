// CS 365 - Lab 1

#include <stdio.h>
#include <string.h>
#include <mpi.h>

int main(int argc, char **argv)
{
	// TODO: add your code here
	MPI_Init(&argc, &argv);

	int rank;
	MPI_Comm_rank(MPI_COMM_WORLD, &rank);

	int size;
	MPI_Comm_size(MPI_COMM_WORLD, &size);

	//printf("Hello from process %i\n", rank);

	int number;
	if (rank == 0) {
		printf("What is the number? ");
		fflush(stdout);
		scanf("%i", &number);
	}

	// Broadcast the number to all processes
	MPI_Bcast(&number, 1, MPI_INT, 0, MPI_COMM_WORLD);

	//printf("Process %i: number is %i\n", rank, number);

	int start, chunk_size;
	chunk_size = number / size;
	start = 1 + (rank * chunk_size);
	if (rank == size-1) {
		// last process handles excess if problem size
		// is not evenly divisible by number of processes
		chunk_size += (number % size);
	}

	// Local computation
	int sum = 0;
	for (int i = start; i < start+chunk_size; i++) {
		sum += i;
	}
	//printf("Process %i: local sum=%i\n", rank, sum);

	// Reduce local sums to compute a global sum
	int global;
	MPI_Reduce(&sum, &global, 1, MPI_INT, MPI_SUM, 0, MPI_COMM_WORLD);
	if (rank == 0) {
		printf("Global sum=%i\n", global);
	}

	MPI_Finalize();

	return 0;
}

