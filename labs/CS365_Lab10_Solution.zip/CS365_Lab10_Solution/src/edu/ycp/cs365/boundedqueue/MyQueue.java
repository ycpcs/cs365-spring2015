package edu.ycp.cs365.boundedqueue;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class MyQueue<E> implements BoundedQueue<E> {
	// You shouldn't need to add any fields
	private final Object lock = new Object();
	private final LinkedList<E> data;
	private final int maxItems;
	private final SimulationObserver<E> observer;

	public MyQueue(SimulationObserver<E> observer, int maxItems) {
		// You shouldn't need to change the constructor
		data = new LinkedList<E>();
		this.maxItems = maxItems;
		this.observer = observer;
	}

	@Override
	public void enqueue(E item) throws InterruptedException {
		synchronized (lock) {
			while (data.size() > maxItems) {
				// queue is full
				observer.producerWaiting();
				lock.wait();
				observer.producerRunning();
			}

			// enqueue
			data.add(item);
			lock.notifyAll();
		}
	}

	@Override
	public E dequeue() throws InterruptedException {
		synchronized (lock) {
			while (data.isEmpty()) {
				// queue is empty
				observer.consumerWaiting();
				lock.wait();
				observer.consumerRunning();
			}

			// dequeue
			E item = data.removeFirst();
			lock.notifyAll();
			return item;
		}
	}

	@Override
	public SimulationObserver<E> getObserver() {
		return observer;
	}

	@Override
	public void getContents(List<E> queueContents) {
		queueContents.clear();
		synchronized (lock) {
			queueContents.addAll(data);
		}
	}
}
