#include <stdio.h>
#include <stdlib.h>
#include "mtqueue.h"

MTQueue *mtqueue_create(void)
{
	MTQueue *q = malloc(sizeof(MTQueue));

	q->head = q->tail = NULL;

	// TODO: initialize mutex and condition variable(s)
	pthread_mutex_init(&q->lock, NULL);
	pthread_cond_init(&q->cond, NULL);

	return q;
}

void mtqueue_enqueue(MTQueue *q, void *item)
{
	// TODO: implement
	pthread_mutex_lock(&q->lock);

	// allocate a new node, add it to the queue
	MTQueueNode *node = malloc(sizeof(*node));
	node->item = item;
	node->next = NULL;
	if (q->head == NULL) {
		// queue is currently empty, node is the new head/tail
		q->head = q->tail = node;
	} else {
		// queue is nonempty, make the node the new tail nod
		q->tail->next = node;
		q->tail = node;
	}

	// wake up consumer (if necessary)
	pthread_cond_broadcast(&q->cond);

	pthread_mutex_unlock(&q->lock);
}

void *mtqueue_dequeue(MTQueue *q)
{
	// TODO: implement
	
	pthread_mutex_lock(&q->lock);

	// wait for queue to be nonempty
	while (q->head == NULL) {
		pthread_cond_wait(&q->cond, &q->lock);
	}

	// remove head node
	MTQueueNode *node = q->head;
	q->head = node->next;
	if (q->head == NULL) {
		// queue became empty
		q->tail = NULL;
		// wake up thread waiting for queue to be empty
		pthread_cond_broadcast(&q->cond);
	}

	pthread_mutex_unlock(&q->lock);

	void *result = node->item;
	free(node);
	return result;
}

void mtqueue_wait_until_empty(MTQueue *q)
{
	// TODO: implement
	pthread_mutex_lock(&q->lock);

	while (q->head != NULL) {
		pthread_cond_wait(&q->cond, &q->lock);
	}

	pthread_mutex_unlock(&q->lock);
}
