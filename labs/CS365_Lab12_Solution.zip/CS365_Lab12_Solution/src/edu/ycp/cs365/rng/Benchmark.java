package edu.ycp.cs365.rng;

import java.util.Scanner;

public class Benchmark {
	private static class Task implements Runnable {
		private RandomNumberGenerator rng;
		private int numIters;
		private volatile long sum;
		
		public Task(RandomNumberGenerator rng, int numIters) {
			this.rng = rng;
			this.numIters = numIters;
			this.sum = 0L;
		}
		
		@Override
		public void run() {
			for (int i = 0; i < numIters; i++) {
				sum += rng.nextInt();
			}
		}
		
		public long getSum() {
			return sum;
		}
	}
	
	public static void main(String[] args) throws InterruptedException {
		@SuppressWarnings("resource")
		Scanner keyboard = new Scanner(System.in);
		
		System.out.print("Number of threads: ");
		int numThreads = keyboard.nextInt();
		
		System.out.print("Number of iterations: ");
		int numIters = keyboard.nextInt();
		
		System.out.print("Implementation (0=blocking, 1=nonblocking): ");
		int choice = keyboard.nextInt();
		RandomNumberGenerator rng = (choice == 0) ? new LockBasedRNG() : new LockFreeRNG();
		
		System.out.print("Starting benchmark...");
		System.out.flush();
		
		long start = System.currentTimeMillis();
		
		// Create tasks
		Task[] tasks = new Task[numThreads];
		for (int i = 0; i < numThreads; i++) {
			tasks[i] = new Task(rng, numIters/numThreads);
		}
		
		// Start threads
		Thread[] threads = new Thread[numThreads];
		for (int i = 0; i < numThreads; i++) {
			threads[i] = new Thread(tasks[i]);
			threads[i].start();
		}
		
		// Wait for threads to complete
		for (int i = 0; i < numThreads; i++) {
			threads[i].join();
		}
		
		long end = System.currentTimeMillis();
		
		System.out.println("done\nFinished in " + (end-start) + " ms");
	}
}
