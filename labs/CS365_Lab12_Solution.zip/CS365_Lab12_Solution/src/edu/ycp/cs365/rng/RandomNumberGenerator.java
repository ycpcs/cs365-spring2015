package edu.ycp.cs365.rng;

public interface RandomNumberGenerator {
	public int nextInt();
}
