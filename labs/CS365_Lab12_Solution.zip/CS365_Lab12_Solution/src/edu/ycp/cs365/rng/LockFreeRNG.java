package edu.ycp.cs365.rng;

import java.util.concurrent.atomic.AtomicLong;

// This version uses AtomicLong and compareAndSet rather than
// blocking synchronization
public class LockFreeRNG implements RandomNumberGenerator {
	private AtomicLong seed;
	
	public LockFreeRNG() {
		seed = new AtomicLong(123L);
	}
	
	public int nextInt() {
		// We may have to attempt updating the seed multiple
		// times due to contention from other threads
		while (true) {
			// Get the current seed
			long origSeed = seed.get();
			
			// Speculatively compute the next seed
			long nextSeed = (origSeed * 0x5DEECE66DL + 0xBL) & ((1L << 48) - 1);
			
			// Use compareAndSet to attempt to replace the current seed
			if (seed.compareAndSet(origSeed, nextSeed)) {
				// Success, return the "random" value based on the
				// computed next seed
				return (int)(nextSeed >>> (48 - 32));
			}
		}
		
	}
}
