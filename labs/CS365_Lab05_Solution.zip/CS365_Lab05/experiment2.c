#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <mpi.h>
#include <stdint.h>

#include "utime.h" // for the utime() function

// Use a 4M transfer
#define BUF_SIZE (4*1024*1024)

int main(int argc, char **argv)
{
	MPI_Init(&argc, &argv);

	int rank;
	MPI_Comm_rank(MPI_COMM_WORLD, &rank);

	uint8_t* buf = malloc(BUF_SIZE);

	MPI_Status unused;

	if (rank == 0) {
		FILE *fp = fopen("/usr/local/data/256M.dat", "rb");
		if (!fp) {
			fprintf(stderr, "Couldn't open data file!\n");
			exit(1);
		}
		size_t nr = fread(buf, 1, BUF_SIZE, fp);
		if (nr != BUF_SIZE) {
			fprintf(stderr, "Read failed\n");
		} else {
			unsigned long start, end;

			start = utime();

			MPI_Send(buf, BUF_SIZE, MPI_BYTE, 1, 0, MPI_COMM_WORLD);

			// expect a 1-byte message as an acknowledgement
			// that the data was received
			char reply;
			MPI_Recv(&reply, 1, MPI_CHAR, 1, 0, MPI_COMM_WORLD, &unused);
			end = utime();

			double sec = ((double)end - (double)start) / 1000000.0;
			double bytes_per_sec = BUF_SIZE/sec;

			printf("%.02lf bytes/sec\n", bytes_per_sec);
		}

		fclose(fp);
	} else {
		// Receive 4M message
		MPI_Recv(buf, BUF_SIZE, MPI_BYTE, 0, 0, MPI_COMM_WORLD, &unused);

		// Send back a one-byte reply
		char reply = '!';
		MPI_Send(&reply, 1, MPI_CHAR, 0, 0, MPI_COMM_WORLD);
	}

	MPI_Finalize();

	return 0;
}
