#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <mpi.h>

#include "utime.h" // for the utime() function

int main(int argc, char **argv)
{
	MPI_Init(&argc, &argv);

	int rank;
	MPI_Comm_rank(MPI_COMM_WORLD, &rank);

	char msg;

	MPI_Status unused;
	if (rank == 0) {
		unsigned long start, end;

		msg = 'Q';
		start = utime();
		MPI_Send(&msg, 1, MPI_CHAR, 1, 0, MPI_COMM_WORLD);
		MPI_Recv(&msg, 1, MPI_CHAR, 1, 0, MPI_COMM_WORLD, &unused);
		end = utime();

		// Convert microseconds to milliseconds
		double ms = ((double)end - (double)start) / 1000.0;
		printf("Latency: %.02lf ms\n", ms);
	} else {
		MPI_Recv(&msg, 1, MPI_CHAR, 0, 0, MPI_COMM_WORLD, &unused);
		MPI_Send(&msg, 1, MPI_CHAR, 0, 0, MPI_COMM_WORLD);
	}

	MPI_Finalize();

	return 0;
}
