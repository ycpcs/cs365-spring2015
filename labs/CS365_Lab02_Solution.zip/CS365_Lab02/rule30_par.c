#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include "rule30.h"

static void barf(const char *msg)
{
	printf("%s: %s\n", msg, strerror(errno));
	MPI_Finalize();
	exit(1);
}

static void print(State *state)
{
	for (int i = 0; i < state->num_cells; i++) {
		printf("%c", state->cur[i] != 0 ? 'x' : ' ');
	}
	printf("\n");
}

int main(int argc, char **argv)
{
	MPI_Init(&argc, &argv);

	int rank, size;
	MPI_Comm_rank(MPI_COMM_WORLD, &rank);
	MPI_Comm_size(MPI_COMM_WORLD, &size);

	// Read initial state (every process can do this)
	FILE *fp = fopen(argv[1], "r");
	if (fp == NULL) {
		barf("Couldn't load initial state");
	}
	State *state = rule30_load(fp);
	fclose(fp);

	// Determine what work this processor should do
	int chunk_size = state->num_cells / size;
	int start = rank * chunk_size;
	if (rank == size - 1) {
		chunk_size += (state->num_cells % size);
	}

	//printf("process %i: range is %i..%i\n", rank, start, (start+chunk_size)-1);

	// Get ready for local computation: for example, copy part of the
	// global data (from state->cur) into a separate array
	// TODO
	State *local_state = malloc(sizeof(State));

	// reserve space for cells computed by neighboring processes
	int local_num_cells = chunk_size + 2;
	//printf("Process %i: allocate %i local cells\n", rank, local_num_cells);
	local_state->num_cells = local_num_cells;
	local_state->cur = malloc(local_num_cells * sizeof(uint8_t));
	local_state->next = malloc(local_num_cells * sizeof(uint8_t));

	// copy values from global array into local array
	for (int i = 0; i < chunk_size; i++) {
		uint8_t cell = state->cur[i + start];
		local_state->cur[i + 1] = cell;
	}

	// set "border" values to 0
	local_state->cur[0] = 0;
	local_state->cur[chunk_size+1] = 0;

	// How many generations to simulate
	int num_gens = atoi(argv[2]);

	int l = 1;
	int lb = 0;
	int r = chunk_size;
	int rb = chunk_size+1;

	for (int i = 1; i <= num_gens; i++) {
		// send left?
		// TODO
		if (rank > 0) {
			//printf("Process %i send left\n", rank);
			MPI_Send(&local_state->cur[l], 1, MPI_BYTE, rank-1, 0, MPI_COMM_WORLD);
		}

		// receive from right?
		// TODO
		if (rank < size-1) {
			//printf("Process %i receive from right\n", rank);
			MPI_Status unused;
			MPI_Recv(&local_state->cur[rb], 1, MPI_BYTE, rank+1, 0, MPI_COMM_WORLD, &unused);
		}

		// send right?
		// TODO
		if (rank < size-1) {
			//printf("Process %i send right\n", rank);
			MPI_Send(&local_state->cur[r], 1, MPI_BYTE, rank+1, 0, MPI_COMM_WORLD);
		}

		// receive from left?
		// TODO
		if (rank > 0) {
			//printf("Process %i receive from left\n", rank);
			MPI_Status unused;
			MPI_Recv(&local_state->cur[lb], 1, MPI_BYTE, rank-1, 0, MPI_COMM_WORLD, &unused);
		}

		// local computation
		// TODO
		rule30_compute_next(local_state->cur, local_state->next, chunk_size+2);

		// flip current and next generation
		// TODO
		rule30_flip(local_state);
	}

#if 0
	// For debugging: just have each local process print it
	// local results
	sleep(rank*2);
	printf("Process %i: ", rank);
	for (int i = 0; i < chunk_size; i++) {
		printf("%i ", local_state->cur[i + 1]);
	}
	printf("\n");
#endif

	// combine solutions
	if (rank == 0) {
		//sleep(size*2 + 1);
		// prepare global data structure
		// TODO

		// copy local data
		// TODO
		memcpy(state->cur, local_state->cur + 1, chunk_size);

		// receive data from other processes
		// TODO
		for (int other = 1; other < size; other++) {
			MPI_Status unused;
			int start_index, howmany;
			MPI_Recv(&start_index, 1, MPI_INT, other, 0, MPI_COMM_WORLD, &unused);
			MPI_Recv(&howmany, 1, MPI_INT, other, 0, MPI_COMM_WORLD, &unused);
//			printf("Receive from %i: %i,%i\n", other, start_index, howmany);
			MPI_Recv(&state->cur[start_index], howmany, MPI_BYTE, other, 0, MPI_COMM_WORLD, &unused);
		}
	} else {
		// Send local data to process 0
		// TODO
		MPI_Send(&start, 1, MPI_INT, 0, 0, MPI_COMM_WORLD);
		MPI_Send(&chunk_size, 1, MPI_INT, 0, 0, MPI_COMM_WORLD);
		MPI_Send(&local_state->cur[1], chunk_size, MPI_BYTE, 0, 0, MPI_COMM_WORLD);
	}

	//printf("Final state:\n");
	if (rank == 0) {
		print(state);
	}

	MPI_Finalize();

	return 0;
}

// vim:ts=2:
