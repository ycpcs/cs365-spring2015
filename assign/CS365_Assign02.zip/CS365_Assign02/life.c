#include <stdio.h>
#include "life.h"

Grid *life_load_board(FILE *fp, const char *filename)
{
	// TODO
	return (Grid *) 0; // replace this
}

void life_compute_next_gen(Grid *grid)
{
	// TODO
}

void life_save_board(FILE *fp, Grid *grid)
{
	// TODO
}
