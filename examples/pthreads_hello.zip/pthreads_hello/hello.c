#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>

// work/task data structure
struct Work {
	// Input to computation
	int thread_num;
	int min, max;
	// Result of computation
	int sum;
};

// worker function
void *worker(void *arg)
{
	struct Work *w = arg;

	printf("Hello from thread %i\n", w->thread_num);

	// Local computation
	w->sum = 0;
	for (int i = w->min; i < w->max; i++) {
		w->sum += i;
	}

	return NULL;
}

int main(void) {
	int n;
	printf("Input value: ");
	scanf("%i", &n);

	int chunk_size = n/8;

	// Use 8 threads to do the computation
	struct Work work[8];
	for (int i = 0; i < 8; i++) {
		work[i].thread_num = i;
		work[i].min = i*chunk_size;
		work[i].max = (i+1)*chunk_size;
		if (i == 7) {
			work[i].max += n%8;
		}
	}

	// Create threads!
	pthread_t thr[8];
	for (int i = 0; i < 8; i++) {
		pthread_create(&thr[i], NULL, &worker, &work[i]);
	}

	// Wait for threads to finish
	for (int i = 0; i < 8; i++) {
		pthread_join(thr[i], NULL);
		printf("Thread %i finished\n", i);
	}

	// Compute global result
	int sum = 0;
	for (int i = 0; i < 8; i++) {
		sum += work[i].sum;
	}

	printf("Sum is %i\n", sum);
	return 0;
}
