#include <unistd.h>
#include <stdio.h> // for perror()
#include <stdlib.h>

#include <sys/types.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <fcntl.h>

#include <netinet/in.h> // for struct sockaddr_in

#include <string.h>

#define PORT 40002
#define BUFSIZE 2000

static void readOneLine(int clientSocket, char buf[], int bufSize);

int main(void)
{
	int serverSocket;
	int rc;
	char buf[BUFSIZE];
	int done = 0;

	serverSocket = socket(PF_INET, SOCK_STREAM, 0);
	if (serverSocket < 0) {
		perror("Couldn't create socket");
		exit(1);
	}

	struct sockaddr_in serverAddr;
	serverAddr.sin_family = AF_INET;
	serverAddr.sin_port = htons(PORT);
	inet_pton(AF_INET, "0.0.0.0", &serverAddr.sin_addr);

	rc = bind(
		serverSocket,
		(struct sockaddr *) &serverAddr,
		sizeof(serverAddr));
	if (rc < 0) {
		perror("Couldn't bind server socket");
		exit(1);
	}

	rc = listen(serverSocket, 5);
	if (rc < 0) {
		perror("Couldn't listen on server socket");
		exit(1);
	}

	while (!done) {
		int clientSocket;
		struct sockaddr_in clientAddr;
		socklen_t clientAddrSize = sizeof(clientAddr);

		clientSocket = accept(
			serverSocket,
			(struct sockaddr*) &clientAddr,
			&clientAddrSize);
		if (clientSocket < 0) {
			perror("Couldn't accept connection");
			exit(1);
		}

		readOneLine(clientSocket, buf, BUFSIZE);

		close(clientSocket);

		write(0, buf, strlen(buf));

		if (strcmp(buf, "quit\r\n") == 0) {
			done = 1;
		}
	}

	close(serverSocket);

	return 0;
}

static void readOneLine(int clientSocket, char buf[], int bufSize)
{
	int totalRead = 0;
	int maxRead = bufSize - 1;
	int done = 0;

	while (!done && totalRead < maxRead) {
		char c;
		int rc;

		rc = read(clientSocket, &c, 1);
		if (rc > 0) {
			// got a byte of data
			buf[totalRead] = c;
			totalRead++;

			// reached end of line?
			if (c == '\n') {
				done = 1;
			}
		} else if (rc == 0) {
			// end of file
			buf[totalRead] = c;
			totalRead++;
			done = 1;
		} else {
			// error
			perror("Error reading from client socket");
			done = 1;
		}
	}

	buf[totalRead] = '\0';
}
